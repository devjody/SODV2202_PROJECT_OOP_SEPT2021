﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movies_Example
{
    public partial class Form1 : Form
    {
        public List<Cart_App_WinForm_v1.Movie> list;
        Cart_App_WinForm_v1.Inventory inventory = new();

        public Form1()
        {
            InitializeComponent();
            list = inventory.InitMoviesList();
            SetMovieData(list);
        }

        private void SetMovieData(List<Cart_App_WinForm_v1.Movie> list)
        {
            MovieTitleLabel.Text = list[0].Name;
            DescLabel.Text = list[0].Desc;
            RatingLabel.Text = list[0].Rating.ToString();
            label9.Text = $"${list[0].Price.ToString()}";
            string path = @"C:\Users\Jody\Downloads\SWAP\Visual Studio Repo\Movies_Example\_images\goon.jpg";
            pictureBox.Image = Image.FromFile(path);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            // Example of clicking image to open a new form / panel / usercontrol
            AnotherForm anotherForm = new AnotherForm();
            anotherForm.Show();
        }
    }
}
