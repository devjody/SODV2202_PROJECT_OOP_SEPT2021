﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CustomComp
{
    public partial class UC_BasketItem : UserControl
    {
        public UC_BasketItem()
        {
            InitializeComponent();
        }

        public string SetTitle
        {
            get => vItemName_Label.Text;
            set => vItemName_Label.Text = value; 
        }
        public string SetShow
        {
            get => vShowingSelected_Label.Text;
            set => vShowingSelected_Label.Text=value;
        }
        public decimal SetQty
        {
            get => vQtyPicker_NUD.Value;
            set => vQtyPicker_NUD.Value = value;
        }
        public double SetPrice
        {
            get => Convert.ToDouble(vTicketPrice_Label.Text);
            set => vTicketPrice_Label.Text = value.ToString();
        }
        private void ClearItem_Label_Click(object sender, EventArgs e)
        {
            UpdateBasketListMethod();
            this.Dispose();
        }
        private void UpdateBasketListMethod()
        {
            // TODO
        }
    }
}
