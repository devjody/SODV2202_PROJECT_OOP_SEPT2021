﻿using System;
using System.Collections.Generic;

namespace Cart_App_WinForm_v1
{
    #region Item Record Declarations - Using record types to add various 'Items' to an inventory class.
    public record Item(int Id, string Name, string ImagePath, double Price); // Using Inheritance.

    public record Movie(int Id, string Name, string Desc, int Duration, int Rating, int Showing, string ImagePath, double Price) : Item(Id, Name, ImagePath, Price);
    #endregion

    #region Inventory Class - Using the record types to make an inventory of movies and snacks, for testing cart.
    public class Inventory
    {
        public List<Movie> InitMoviesList()
        {
            var movieInv = new List<Movie>()
                {
                new(51,"Matrix Reloaded", "The Matrix Reloaded is a 2003 American science fiction action film written \nand directed by the Wachowskis. It is a sequel to The Matrix, and the second installment in The Matrix film series. \nThe film premiered on May 7, 2003, in Westwood, Los Angeles, California, and had its worldwide release by Warner Bros.", 120, 15, 1, @"\images\m1.png", 10.99),
                new(52,"Avatar", "Avatar is a 2009 American epic science fiction film directed, written, produced, \nand co-edited by James Cameron and starring Sam Worthington, Zoe Saldana, Stephen Lang, Michelle Rodriguez, \nand Sigourney Weaver.", 150, 0, 1, @"\images\m2.png", 14.99),
                new(53,"The Secret Life of Pets 2", "The Secret Life of Pets 2 is a 2019 American computer-animated comedy \nfilm produced by Illumination, directed by Chris Renaud, co-directed by Jonathan del Val, and written by Brian Lynch. \nIt is the sequel to The Secret Life of Pets, and the second feature film in the franchise.", 130, 0, 2, @"\images\m3.png", 14.99),
                new(54,"Titanic", "Titanic is a 1997 American epic romance and disaster film directed, written, produced, \nand co-edited by James Cameron. Incorporating both historical and fictionalized aspects, it is based on accounts of \nthe sinking of the RMS Titanic, and stars Leonardo DiCaprio and Kate Winslet as members of different social classes \nwho fall in love aboard the ship during its ill-fated maiden voyage.", 90, 15, 2, @"\images\m4.png", 14.99),
                new(55,"Predator 2", "Predator 2 is a 1990 American science fiction action film written by brothers Jim \nand John Thomas, directed by Stephen Hopkins, and starring Danny Glover, Ruben Blades, Gary Busey, María Conchita Alonso, \nBill Paxton, and Kevin Peter Hall.", 210, 18, 3, @"\images\m5.png", 14.99),
                new(56,"Breakfast at Tiffany's", "Breakfast at Tiffany's is a 1961 American romantic comedy film directed \nby Blake Edwards, written by George Axelrod, adapted from Truman Capote's 1958 novella of the same name, \nand starring Audrey Hepburn as Holly Golightly, a naïve, eccentric café society girl who falls in love with a struggling writer", 205, 15, 3, @"\images\m6.png", 10.99),
                };
            return movieInv;
        }
    } 
    #endregion
}