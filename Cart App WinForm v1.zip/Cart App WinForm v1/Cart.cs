﻿using CustomComp;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Cart_App_WinForm_v1
{
    public partial class Cart : Form
    {
        // To populate some items so they can be added to a 'basket'
        List<Movie> movieList;
        Inventory inventory;
 
        public Cart()
        {
            InitializeComponent();
            inventory = new();
            movieList = inventory.InitMoviesList();

            /// Basket CLass >> 0 > 100 items in it

            UC_BasketItem b1 = new(); // "Matrix Revolutions", 11.99, 3, "11:00pm"
            PostBasketItem(b1, 10, 10);
        }

        private void PostBasketItem(UC_BasketItem basketLineItem, int x, int y)
        {
            basketLineItem.Location = new Point(x, y);

            basketLineItem.SetTitle = "Matrix";
            basketLineItem.SetShow = "11.00am";
            basketLineItem.SetQty = 3;
            basketLineItem.SetPrice = 11.99;
            
            this.vItemised_Panel.Controls.Add(basketLineItem);
        }

        private void vPurchase_Button_Click(object sender, System.EventArgs e)
        {
            DialogResult result3 = MessageBox.Show("Finalize Checkout Payment?",
               "Confirm Purchase",
               MessageBoxButtons.OKCancel,
               MessageBoxIcon.Information,
               MessageBoxDefaultButton.Button1);
        }
        private void vCancel_Button_Click(object sender, System.EventArgs e)
        {
            DialogResult result3 = MessageBox.Show("This will cancel your checkout, are you sure?",
               "Confirm Cancel",
               MessageBoxButtons.OKCancel,
               MessageBoxIcon.Warning,
               MessageBoxDefaultButton.Button2);
        }


    }
}

/* <div>Icons made by <a href="https://www.freepik.com" title="Freepik">Freepik</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div> */
