﻿namespace CustomComp
{
    partial class UC_BasketItem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ItemLabelName = new System.Windows.Forms.Label();
            this.vItemName_Label = new System.Windows.Forms.Label();
            this.vTicketPrice_Label = new System.Windows.Forms.Label();
            this.costLabeldollar = new System.Windows.Forms.Label();
            this.vItemIcon_PictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.vShowingSelected_Label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.vQtyPicker_NUD = new System.Windows.Forms.NumericUpDown();
            this.ClearItem_Label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.vItemIcon_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vQtyPicker_NUD)).BeginInit();
            this.SuspendLayout();
            // 
            // ItemLabelName
            // 
            this.ItemLabelName.AutoSize = true;
            this.ItemLabelName.Location = new System.Drawing.Point(82, 5);
            this.ItemLabelName.Name = "ItemLabelName";
            this.ItemLabelName.Size = new System.Drawing.Size(34, 15);
            this.ItemLabelName.TabIndex = 0;
            this.ItemLabelName.Text = "Item:";
            // 
            // vItemName_Label
            // 
            this.vItemName_Label.AutoSize = true;
            this.vItemName_Label.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.vItemName_Label.Location = new System.Drawing.Point(91, 20);
            this.vItemName_Label.Name = "vItemName_Label";
            this.vItemName_Label.Size = new System.Drawing.Size(176, 25);
            this.vItemName_Label.TabIndex = 1;
            this.vItemName_Label.Text = "SOME ITEM NAME";
            // 
            // vTicketPrice_Label
            // 
            this.vTicketPrice_Label.AutoSize = true;
            this.vTicketPrice_Label.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.vTicketPrice_Label.Location = new System.Drawing.Point(299, 74);
            this.vTicketPrice_Label.Name = "vTicketPrice_Label";
            this.vTicketPrice_Label.Size = new System.Drawing.Size(56, 25);
            this.vTicketPrice_Label.TabIndex = 2;
            this.vTicketPrice_Label.Text = "00.00";
            // 
            // costLabeldollar
            // 
            this.costLabeldollar.AutoSize = true;
            this.costLabeldollar.Location = new System.Drawing.Point(290, 52);
            this.costLabeldollar.Name = "costLabeldollar";
            this.costLabeldollar.Size = new System.Drawing.Size(40, 15);
            this.costLabeldollar.TabIndex = 3;
            this.costLabeldollar.Text = "CAD $";
            // 
            // vItemIcon_PictureBox
            // 
            this.vItemIcon_PictureBox.Image = global::Cart_App_WinForm_v1.Properties.Resources.Ticket_Icon;
            this.vItemIcon_PictureBox.Location = new System.Drawing.Point(3, 3);
            this.vItemIcon_PictureBox.Name = "vItemIcon_PictureBox";
            this.vItemIcon_PictureBox.Size = new System.Drawing.Size(64, 64);
            this.vItemIcon_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.vItemIcon_PictureBox.TabIndex = 4;
            this.vItemIcon_PictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(290, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Showing:";
            // 
            // vShowingSelected_Label
            // 
            this.vShowingSelected_Label.AutoSize = true;
            this.vShowingSelected_Label.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.vShowingSelected_Label.Location = new System.Drawing.Point(299, 20);
            this.vShowingSelected_Label.Name = "vShowingSelected_Label";
            this.vShowingSelected_Label.Size = new System.Drawing.Size(90, 25);
            this.vShowingSelected_Label.TabIndex = 6;
            this.vShowingSelected_Label.Text = "00:00 AM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Qty:";
            // 
            // vQtyPicker_NUD
            // 
            this.vQtyPicker_NUD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.vQtyPicker_NUD.Location = new System.Drawing.Point(91, 70);
            this.vQtyPicker_NUD.Name = "vQtyPicker_NUD";
            this.vQtyPicker_NUD.Size = new System.Drawing.Size(80, 29);
            this.vQtyPicker_NUD.TabIndex = 8;
            // 
            // ClearItem_Label
            // 
            this.ClearItem_Label.AutoSize = true;
            this.ClearItem_Label.ForeColor = System.Drawing.Color.Gray;
            this.ClearItem_Label.Location = new System.Drawing.Point(18, 84);
            this.ClearItem_Label.Name = "ClearItem_Label";
            this.ClearItem_Label.Size = new System.Drawing.Size(32, 15);
            this.ClearItem_Label.TabIndex = 9;
            this.ClearItem_Label.Text = "clear";
            this.ClearItem_Label.Click += new System.EventHandler(this.ClearItem_Label_Click);
            // 
            // UC_BasketItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ClearItem_Label);
            this.Controls.Add(this.vQtyPicker_NUD);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.vShowingSelected_Label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.vItemIcon_PictureBox);
            this.Controls.Add(this.costLabeldollar);
            this.Controls.Add(this.vTicketPrice_Label);
            this.Controls.Add(this.vItemName_Label);
            this.Controls.Add(this.ItemLabelName);
            this.Name = "UC_BasketItem";
            this.Size = new System.Drawing.Size(400, 109);
            ((System.ComponentModel.ISupportInitialize)(this.vItemIcon_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vQtyPicker_NUD)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ItemLabelName;
        private System.Windows.Forms.Label vItemName_Label;
        private System.Windows.Forms.Label vTicketPrice_Label;
        private System.Windows.Forms.Label costLabeldollar;
        private System.Windows.Forms.PictureBox vItemIcon_PictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label vShowingSelected_Label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown vQtyPicker_NUD;
        private System.Windows.Forms.Label ClearItem_Label;
    }
}
